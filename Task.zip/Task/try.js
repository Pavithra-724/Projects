function myFunction() {
    alert("Please fill all details!");
  }